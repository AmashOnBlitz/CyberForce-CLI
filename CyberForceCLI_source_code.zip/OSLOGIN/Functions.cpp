#include <iostream>
#include <string>
#include "functions.h"
#include "helperfunctions.h"
#include "../../installerfinal/installerfinal/helperfunctions.h"
#include <conio.h>
#ifdef _WIN32
#include <windows.h>  // For Sleep() on Windows
#else
#include <unistd.h>   // For sleep() on Linux/macOS
#endif

std::string checkOS() {
#ifdef _WIN32
	typeEffect("Running on Windows(32 - bit or 64 - bit)", 10);
	return "Windows";
#elif __linux__
	typeEffect("Running on Linux", 10);
	return "Linux";
#elif __APPLE__
	typeEffect("Running on macOS", 10);
	return "apple";
#else
	typeEffect("Error in OS detection", 10);
	return "Unknown";
#endif
	std::cout << coutBoldRedText("Error in OS detection") << getCurrentTime << getCurrentDate << std::endl;
	return "Unknown";
}

std::string getHiddenPassword() {
	std::string password;
	char ch;
	while ((ch = _getch()) != 13) {
		if (ch == 8 && !password.empty()) {
			std::cout << "\b \b";
			password.pop_back();
		}
		else if (ch != 8) {
			password.push_back(ch);
			std::cout << '*';
		}
	}
	std::cout << std::endl;
	return password;
}

void freezeScreen(int seconds) {
#ifdef _WIN32
	Sleep(seconds * 1000); // Convert seconds to milliseconds for Windows
#else
	sleep(seconds);  // Linux/macOS uses seconds directly
#endif
}
