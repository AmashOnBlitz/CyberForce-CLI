#include <string>
extern sqlite3* db;
void executeSQL(const std::string& sql);
void initDatabase();
bool checkLoginCredentials(std::string username, std::string password);


