#include "maintoolfunc.h"
#include <iostream>
#include <string>
#include "Functions.h"
#include <winsock2.h>
#include <ws2tcpip.h>  
#include <sqlite3.h>
#include <vector>
#include "CRUDDatabase.h"
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <sqlite3.h>
#include <direct.h>
#include <regex>
#include <algorithm>
#include <thread>
#include <chrono>
#include <conio.h>  // For _kbhit() and _getch()
#include <windows.h> 
#include "../../installerfinal/installerfinal/helperfunctions.h"
#define MAX_PATH_LENGTH 260
#pragma comment(lib, "ws2_32.lib")
void askJohn();
void scanTopPorts(const std::string& username);
void scanWholePorts(const std::string& username);

void checkCommand(const std::string& command, const std::string& username) {
    if (command == "1") {
        scanWholePorts(username);
    }
    else if (command == "2") {
        scanTopPorts(username);
    }
    else {
        std::cout << coutRedText("Invalid command") << std::endl;
        typeEffectWithoutEndingLine(coutBoldText("[+] >> "), 10);
    }
}


void viewHistory(const std::string& username) {
    std::string sql = "SELECT ip, port, status, timestamp FROM history WHERE username = '" + username + "' ORDER BY timestamp DESC;";
    sqlite3_stmt* stmt;

    if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, 0) == SQLITE_OK) {
        std::cout << "\n=== Scan History ===\n";
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            std::cout << "IP: " << sqlite3_column_text(stmt, 0)
                << " | Port: " << sqlite3_column_int(stmt, 1)
                << " | Status: " << sqlite3_column_text(stmt, 2)
                << " | Time: " << sqlite3_column_text(stmt, 3) << std::endl;
        }
    }
    sqlite3_finalize(stmt);
}

void scanPorts(const std::string& username) {
    std::string command;
    clearScreen();
    std::cout << coutBoldUnderlineText(coutBlueText("Which option : \n 1.Scan Whole Ports \n 2.Scan Top 100 Ports (Works in most cases) \n"));
    typeEffectWithoutEndingLine(coutBoldText("[+] >> "), 10);

    std::getline(std::cin >> std::ws, command);  // Get user input
    checkCommand(command, username);  // Pass command to function
}


void scanTopPorts(const std::string& username) {
    std::string ip;
    std::cout << "Enter IP address to scan: ";
    std::cin >> ip;

    std::string outputFile = "result.txt";

    std::string cmd = "\"tools\\nmap\\nmap.exe\" " + ip + " --top-ports 100 -oN result.txt";

    system(cmd.c_str());

    // Read the output file
    std::ifstream file(outputFile);
    std::string line;
    std::regex portRegex(R"((\d+)/tcp\s+open)");

    while (std::getline(file, line)) {
        std::smatch match;
        if (std::regex_search(line, match, portRegex)) {
            int port = std::stoi(match[1].str());

            std::string sql = "INSERT INTO history (username, ip, port, status, timestamp) VALUES ('" + username + "', '" + ip + "', " + std::to_string(port) + ", 'OPEN', datetime('now', 'localtime'));";
            executeSQL(sql);
            std::cout << "Port " << port << ": OPEN\n";
        }
    }
    file.close();
}

void scanWholePorts(const std::string& username) {
    std::string ip;
    std::cout << "Enter IP address to scan: ";
    std::cin >> ip;

    std::string outputFile = "result.txt";

    std::string cmd = "tools\\nmap\\nmap.exe " + ip + " -p- -oN result.txt";
    system(cmd.c_str());

    // Read the output file
    std::ifstream file(outputFile);
    std::string line;
    std::regex portRegex(R"((\d+)/tcp\s+open)");

    while (std::getline(file, line)) {
        std::smatch match;
        if (std::regex_search(line, match, portRegex)) {
            int port = std::stoi(match[1].str());

            std::string sql = "INSERT INTO history (username, ip, port, status, timestamp) VALUES ('" + username + "', '" + ip + "', " + std::to_string(port) + ", 'OPEN', datetime('now', 'localtime'));";
            executeSQL(sql);
            std::cout << "Port " << port << ": OPEN\n";
        }
    }
    file.close();
}


void activeConnectionsMonitor() {
    clearScreen();
    typeEffect("Initializing Network Scanner...",10);
    std::this_thread::sleep_for(std::chrono::seconds(1));
    typeEffect("Scanning for active connections...",10);
    std::this_thread::sleep_for(std::chrono::seconds(1));
    typeEffect("Fetching network data...",10);
    std::this_thread::sleep_for(std::chrono::seconds(1));
    clearScreen();
    std::cout << "\n=============================\n";
    typeEffect("Active Network Connections:",10);
    std::cout << "=============================\n";
    system("Color 0A");
    system("netstat -ano");
    std::this_thread::sleep_for(std::chrono::milliseconds(200));
    coutCenterTextWithoutEndingLine("XXX=============================XXX");
    system("color 07");
}


std::string JTR_PATH = "tools\\john\\john-1.9.0-jumbo-1-win64\\run\\john.exe";


void runJohnTheRipper(const std::string& hashFile, int mode, const std::string& wordlist) {
    std::string command;

    switch (mode) {
    case 1:
        command = JTR_PATH + " " + hashFile;
        break;
    case 2:
        command = JTR_PATH + " --wordlist=" + wordlist + " " + hashFile;
        break;
    case 3:
        command = JTR_PATH + " --show " + hashFile;
        break;
    default:
        std::cout << "Invalid option!\n";
        return askJohn();
    }

    system(command.c_str());

    if (mode == 2) {
        std::cout << "\nNo password found. Would you like to try an incremental brute-force attack? (y/n): ";
        char response;
        std::cin >> response;
        if (response == 'y' || response == 'Y') {
            std::cout << "Select an incremental mode:\n";
            std::cout << "1. ASCII (Full ASCII set)\n";
            std::cout << "2. Digits (Only numbers)\n";
            std::cout << "3. Alnum (Letters and numbers)\n";
            std::cout << "Enter your choice: ";
            int incMode;
            std::cin >> incMode;

            std::string incType;
            if (incMode == 1) incType = "ASCII";
            else if (incMode == 2) incType = "Digits";
            else if (incMode == 3) incType = "Alnum";
            else incType = "ASCII";  // Default

            command = JTR_PATH + " --incremental=" + incType + " " + hashFile;
            system(command.c_str());
        }
    }
}

void askJohn() {
    std::string hashFile;
    std::string  wordlist;
    int wordlistChoice;
    int choice;

    std::cout << "========== John the Ripper Integration ==========\n";
    std::cout << "Enter the path to the hash file: ";
    std::cin >> hashFile;

    std::cout << "\nSelect an attack mode:\n";
    std::cout << "1. Default Cracking Mode\n";
    std::cout << "2. Wordlist Attack (rockyou.txt)\n";
    std::cout << "3. Show Cracked Passwords\n";
    std::cout << "Enter your choice: ";
    std::cin >> choice;
    if (choice == 2) {
        std::cout << "\nSelect a wordlist:\n";
        std::cout << "1. rockyou.txt (General passwords)\n";
        std::cout << "2. wifiTop5000.txt (WiFi passwords)\n";
        std::cout << "Enter your choice: ";
        std::cin >> wordlistChoice;

        // Assign wordlist path based on selection
        if (wordlistChoice == 1) {
            wordlist = "tools\\wordlist\\rockyou.txt";
        }
        else if (wordlistChoice == 2) {
            wordlist = "tools\\wordlist\\wifiTop5000.txt";
        }
        else {
            std::cout << "Invalid wordlist choice! Defaulting to rockyou.txt.\n";
            wordlist = "tools\\wordlist\\rockyou.txt";
        }
    }

    runJohnTheRipper(hashFile, choice, wordlist);
}

void instaBruteForce() {
    std::string JTR_PATH = "tools\\instapasswordcracker.exe";
    std::string command = "start cmd /k \"" + JTR_PATH + "\"";
    clearScreen();
    typeEffect(coutBoldGreenText("You can use mutilple window by passing '5' again and again which would be more relaiable !\n"), 40);
    typeEffect(coutBoldGreenText("Please check the opened window once ! , you will be prompted for username in which you can put email or username (one at a time only)"), 40);
    typeEffectWithoutEndingLine(coutBoldRedText("Starting app ."), 10);
    typeEffectWithoutEndingLine(coutBoldRedText("."), 20);
    typeEffectWithoutEndingLine(coutBoldRedText("."), 30);
    typeEffectWithoutEndingLine(coutBoldRedText("."), 35);
    typeEffectWithoutEndingLine(coutBoldRedText("."), 40);
    typeEffectWithoutEndingLine(coutBoldRedText("."), 30);
    clearScreen();
    Sleep(6000);
    system(command.c_str());
    std::cout << coutBoldGreenText("Started In Another Window You Can Continue Using Here!.\n");
    std::cout << coutBoldGreenText("You can use mutilple window by passing '5' which would be more relaiable !\n");
    std::cout << coutBoldGreenText("Please check the opened window once ! , you will be prompted for username in which you can put email or username (one at a time only)");

};

void exifTool() {
    std::string filePath;
    std::cout << "Enter image file path: ";
    std::getline(std::cin >> std::ws, filePath);  // Handles input correctly

    std::wstring exePath = L"tools\\exiftool-13.19_64\\exiftool.exe";
    std::wstring command = L"\"" + exePath + L"\" -a -u -g1 \"" + std::wstring(filePath.begin(), filePath.end()) + L"\"";


    STARTUPINFO si = { sizeof(si) };
    PROCESS_INFORMATION pi;

    if (CreateProcessW(NULL, &command[0], NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
        WaitForSingleObject(pi.hProcess, INFINITE);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
    else {
        std::cerr << "Error running ExifTool! Check file path.\n";
    }
    Sleep(10000);
}


