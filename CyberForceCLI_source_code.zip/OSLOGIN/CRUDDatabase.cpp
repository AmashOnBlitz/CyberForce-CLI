#include "sqlite3.h"  
#include "helperfunctions.h"
#include "functions.h"
#include "../../installerfinal/installerfinal/helperfunctions.h"
#include "CRUDDatabase.h"

sqlite3* db = nullptr;

void executeSQL(const std::string& sql) {
    char* errMsg = 0;
    if (sqlite3_exec(db, sql.c_str(), 0, 0, &errMsg) != SQLITE_OK) {
        std::cout << "SQLite Error: " << errMsg << std::endl;
        sqlite3_free(errMsg);
    }
}

void initDatabase() {
    if (sqlite3_open("scanner.db", &db)) {
        typeEffect(coutBoldRedText("Error opening database!"),10);
    }
    else {
        typeEffect(coutGreenText("Database opened successfully!"),10);
    }

    // Create user table
    executeSQL("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT);");

    // Create history table
    executeSQL("CREATE TABLE IF NOT EXISTS history (id INTEGER PRIMARY KEY, username TEXT, ip TEXT, port INTEGER, status TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP);");
}



bool checkLoginCredentials(std::string username,std::string password) {
    std::string sql = "SELECT * FROM users WHERE username = '" + username + "' AND password = '" + password + "';";
    sqlite3_stmt* stmt;

    if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, 0) == SQLITE_OK) {
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            std::cout << "Login successful!" << std::endl;
            sqlite3_finalize(stmt);
            return true;
        }
        else {
            std::cout << "Invalid username or password!" << std::endl;
        }
    }
    sqlite3_finalize(stmt);
    return false;
}
