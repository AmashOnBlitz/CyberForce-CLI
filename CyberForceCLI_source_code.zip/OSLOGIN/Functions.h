#pragma once
std::string checkOS();
std::string getHiddenPassword();
void freezeScreen( int seconds);