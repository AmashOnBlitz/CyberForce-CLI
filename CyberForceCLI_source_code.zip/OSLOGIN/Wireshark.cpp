#include "Wireshark.h"
#include <string>
#include <iostream>
#include <cstdlib> 
#include "maintoolfunc.h"
#include <iostream>
#include <string>
#include "Functions.h"
#include <winsock2.h>
#include <ws2tcpip.h>  
#include <sqlite3.h>
#include <vector>
#include "CRUDDatabase.h"
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <sqlite3.h>
#include <direct.h>
#include <regex>
#include <algorithm>
#include <thread>
#include <chrono>
#include <conio.h>  // For _kbhit() and _getch()
#include <windows.h> 
#include "../../installerfinal/installerfinal/helperfunctions.h"
using namespace std;

const std::string TSHARK_PATH = "tools\\Wireshark\\tshark.exe";  // Full path to tshark.exe

void Wireshark::listInterfaces() {
    std::string command = TSHARK_PATH + " -D";
    system(command.c_str());
}


void Wireshark::capturePackets(int interfaceNum) {
    int timeLimit = 60;
    clearScreen();
    typeEffect(coutBoldRedText("Listning for 1 minute"),20);
    Sleep(3000);
    std::string command = TSHARK_PATH + " -i " + std::to_string(interfaceNum) + " -a duration:" + std::to_string(timeLimit);
    system(command.c_str());
}

void Wireshark::saveCapture(int interfaceNum, const std::string& filename) {
    int timeLimit = 60;
    clearScreen();
    typeEffect(coutBoldRedText("Listning for 1 minute"), 20);
    Sleep(3000);
    std::string command = TSHARK_PATH + " -i " + std::to_string(interfaceNum) + " -a duration:" + std::to_string(timeLimit) + " -w " + filename;
    system(command.c_str());
}

void Wireshark::readCapture(const std::string& filename) {
    std::string command = TSHARK_PATH + " -r " + filename;
    system(command.c_str());
}

void Wireshark::filterCapture(int interfaceNum, const std::string& filter) {
    std::string command = TSHARK_PATH + " -i " + std::to_string(interfaceNum) + " -Y \"" + filter + "\"";
    system(command.c_str());
}

void Wireshark::extractIPs(int interfaceNum) {
    std::string command = TSHARK_PATH + " -i " + std::to_string(interfaceNum) + " -T fields -e ip.src -e ip.dst";
    system(command.c_str());
}

void Wireshark::searchPackets(int interfaceNum, const std::string& keyword) {
    std::string command = TSHARK_PATH + " -i " + std::to_string(interfaceNum) + " -Y \"frame contains '" + keyword + "'\"";
    system(command.c_str());
}
void wiresharkmenu() {
    Wireshark wireshark; 
    int choice, interfaceNum;
    string filename, filter, keyword;

    while (true) {
        cout << "\n=== TShark Command-Line Tool ===\n";
        cout << "1. List Available Interfaces\n";
        cout << "2. Capture Packets (Live)\n";
        cout << "3. Save Capture to File\n";
        cout << "4. Read Saved Capture\n";
        cout << "5. Capture Only Specific Traffic (Filter)\n";
        cout << "6. Extract Source & Destination IPs\n";
        cout << "7. Search for Keyword in Packets\n";
        cout << "8. Exit\n";
        cout << "Choose an option: ";
        cin >> choice;

        switch (choice) {
        case 1:
            wireshark.listInterfaces();
            break;

        case 2:
            wireshark.listInterfaces();
            cout << "Enter interface number: ";
            cin >> interfaceNum;
            wireshark.capturePackets(interfaceNum);
            break;

        case 3:
            wireshark.listInterfaces();
            cout << "Enter interface number: ";
            cin >> interfaceNum;
            cout << "Enter filename to save (e.g., capture.pcap): ";
            cin >> filename;
            wireshark.saveCapture(interfaceNum, filename);
            break;

        case 4:
            cout << "Enter filename to read (e.g., capture.pcap): ";
            cin >> filename;
            wireshark.readCapture(filename);
            break;

        case 5:
            wireshark.listInterfaces();
            cout << "Enter interface number: ";
            cin >> interfaceNum;
            cout << "Enter filter (e.g., http, tcp, udp, dns): ";
            cin >> filter;
            wireshark.filterCapture(interfaceNum, filter);
            break;

        case 6:
            wireshark.listInterfaces();
            cout << "Enter interface number: ";
            cin >> interfaceNum;
            wireshark.extractIPs(interfaceNum);
            break;

        case 7:
            wireshark.listInterfaces();
            cout << "Enter interface number: ";
            cin >> interfaceNum;
            cout << "Enter keyword to search in packets: ";
            cin >> keyword;
            wireshark.searchPackets(interfaceNum, keyword);
            break;

        case 8:
            cout << "Exiting...\n";
            return;

        default:
            cout << "Invalid option. Try again.\n";
            break;
        }
    }
}
