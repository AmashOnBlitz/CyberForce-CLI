#include <iostream>
#include <winsock2.h>
#include <vector>
#include <string>
#include "sqlite3.h"  
#include "helperfunctions.h"
#include "CRUDDatabase.h"
#include <conio.h>
#include "../../installerfinal/installerfinal/helperfunctions.h"
#include "functions.h"
#include <algorithm>
#include <filesystem>
#include "Wireshark.h"
#include <filesystem>
#include "maintoolfunc.h"
#pragma comment(lib, "ws2_32.lib") 
int main();
std::string getUserCommand(std::string& username);
int mainTool(std::string& username);
void showHelp();



HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);


void registerUser() {
	std::string username, password;

	std::cout << coutBlueText(coutBoldText("Enter your username : "));
	SetConsoleTextAttribute(hConsole, 6);
	std::cin >> username;
	SetConsoleTextAttribute(hConsole, 7);
	std::cout << coutBlueText(coutBoldText("Enter your password : "));
	SetConsoleTextAttribute(hConsole, 6);
	password = getHiddenPassword();
	SetConsoleTextAttribute(hConsole, 7);
	std::string sql = "INSERT INTO users (username, password) VALUES ('" + username + "', '" + password + "');";
	executeSQL(sql);
	freezeScreen(2);
	typeEffect(coutGreenText("User registered successfully"), 10);
	freezeScreen(2);
	clearScreen();
	getUserCommand(username);
}


bool loginUser(std::string& username) {
	std::string password;
	std::cout << coutBlueText(coutBoldText("Enter your username : "));
	std::cin >> username;
	std::cout << coutBlueText(coutBoldText("Enter your password : "));
	SetConsoleTextAttribute(hConsole, 6);
	password = getHiddenPassword();
	SetConsoleTextAttribute(hConsole, 7);
	std::string sql = "SELECT * FROM users WHERE username = '" + username + "' AND password = '" + password + "';";
	sqlite3_stmt* stmt;
	if (sqlite3_prepare_v2(db, sql.c_str(), -1, &stmt, 0) == SQLITE_OK) {
		if (sqlite3_step(stmt) == SQLITE_ROW) {
			typeEffect(coutGreenText("Login successful"), 10);
			sqlite3_finalize(stmt);
			mainTool(username);
			return true;
		}
		else {
			typeEffect(coutRedText("Invalid credentials"), 10);
			getUserCommand(username);
		}
	}
	sqlite3_finalize(stmt);
	return false;
}



void showHelp() {
	std::cout << "Register = Register a new user" << std::endl;
	std::cout << "Login = Login with Credentials" << std::endl;
	std::cout << "Exit = for exiting" << std::endl;
	main();
}
std::string getUserCommand(std::string& username) {
	std::string command;
	while (true) {
		std::getline(std::cin, command);

		// Convert input to lowercase for case insensitivity
		std::transform(command.begin(), command.end(), command.begin(), ::tolower);

		if (command == "register") {
			registerUser();
			return command;
		}
		else if (command == "login") {
			loginUser(username);
			return username;
		}
		else if (command == "exit") {
			std::cout << "Exiting application..." << std::endl;
			exit(0);
		}
		else if (command == "help") {
			showHelp();
		}
		else {
			std::cout << coutRedText("Invalid command") << std::endl;
			typeEffectWithoutEndingLine(coutBoldText("[+] >> "), 10);
			getUserCommand(username);
		}
	}
}

int main() {
	std::string username;
	std::string choice;
	std::string operatingSystem;

	try {
		initDatabase();
		typeEffect(coutGreenText("Module loaded successfully "), 10);
		typeEffectWithoutEndingLine(getCurrentTime(), 10);
		std::cout << " ";
		typeEffect(getCurrentDate(), 10);
		operatingSystem = checkOS();
		if (std::filesystem::exists("tools\\")) {
			typeEffect("tools exists ... ",10);
		}
		else {
			typeEffect(coutBoldRedText("Directory does not exist. This will cause errors in program! Please make a tools folder (names tools) where this apps exe file is located"),30);
		}
		if (std::filesystem::exists("tools\\instapasswordcracker.exe")) {
			typeEffect("instapasswordcracker.exe tool exists ... ", 10);
		}
		else {
			typeEffect(coutBoldRedText("instapasswordcracker.exe Tool does not exist. This will cause errors in program! Please download it an put it in tools\\instapasswordcracker.exe"), 30);
		}
		if (std::filesystem::exists("tools\\john\\john-1.9.0-jumbo-1-win64\\run\\john.exe")) {
			typeEffect("John The Ripper  exists ... ", 10);
		}
		else {
			typeEffect(coutBoldRedText("John The Ripper Tool does not exist. This will cause errors in program! Please download it an put it in tools\\john\\john-1.9.0-jumbo-1-win64\\run\\john.exe"), 30);
		}
		if (std::filesystem::exists("tools\\nmap\\nmap.exe")) {
			typeEffect("Nmap  exists ... ", 10);
		}
		else {
			typeEffect(coutBoldRedText("Nmap Tool does not exist. This will cause errors in program! Please download it an put it in tools\\nmap\\nmap.exe"), 30);
		}
		if (std::filesystem::exists(R"(tools\\exiftool-13.19_64\\exiftool.exe)")) {
			typeEffect("exiftool exists ... ", 10);
		}
		else {
			typeEffect(coutBoldRedText("exiftool tool does not exist. This will cause errors in program! Please download it an put it in tools\\exiftool-13.19_64\\exiftool.exe"), 30);
		}
		if (std::filesystem::exists("tools\\Wireshark\\tshark.exe")) {
			typeEffect("tshark exists ... ", 10);
		}
		else {
			typeEffect(coutBoldRedText("tshark tool does not exist. This will cause errors in program! Please download it an put it in tools\\Wireshark\\tshark.exe"), 30);
		}
		if (std::filesystem::exists("tools\\wordlist\\rockyou.txt")) {
			typeEffect("Rockyou  exists ... ", 10);
		}
		else {
			typeEffect(coutBoldRedText("Rockyou list does not exist. This will cause errors in program! Please download it an put it in tools\\wordlist\\rockyou.txt"), 30);
		}
		if (std::filesystem::exists("tools\\wordlist\\wifiTop5000.txt")) {
			typeEffect("wifiTop5000  exists ... ", 10);
		}
		else {
			typeEffect(coutBoldRedText("wifiTop5000 list does not exist. This will cause errors in program! , Please download it an put it in tools\\wordlist\\wifiTop5000.txt"), 30);
		}
		
		freezeScreen(2);
		clearScreen();
	}
	catch (std::exception& e) {
		std::cout << coutBoldRedText(e.what()) << std::endl;
	}
	typeEffectWithoutEndingLine(coutBoldText(coutBoldItalicRedText("Welcome to the application,This aplication is made by Amash on blitz for just education purposes and legal use , any illegal use by this application with have no relations with the author. YOU WILL BE RESPONSIBLE OF IT !\n")), 15);
	typeEffectWithoutEndingLine(coutBoldText(coutBoldYellowText("BY USING THE APPLICATION YOU AGREE TO THESE TERMS AND CONDITIONS ")), 15);
	typeEffectWithoutEndingLine(coutBoldText(coutBoldGreenText("\nPress any key to continue...")), 10);
	_getch();
	clearScreen();
	coutCenterText(coutBoldGreenText("CyberForce CLI"));
	coutCenterText(coutBoldGreenText("Welcome to the application"));
	coutCenterText(coutBoldItalicRedText("If you are new just type Register otherwise type Login"));
	std::cout << coutBoldYellowText("FOR USING THE TOOL YOU FIRST NEED TO LOGIN , AND YOU CAN REGISTER WITH ANY USERNAME AND PASSWORD , THAT IS USE TO SAVE HISTORY OF SCANS!") << std::endl;
	typeEffect(coutBlueText(coutBoldText("Enter your choice (Register/Login/Exit/Help)")), 10);
	typeEffectWithoutEndingLine(coutBoldText("[+] >> "), 10);
	getUserCommand(username);
}
	

int mainTool(std::string& username) {
	int choice;
	clearScreen();
	username = username;
	coutCenterText(coutBoldGreenText("CyberForce CLI"));
	coutCenterText(coutBoldGreenText("Welcome "));
	coutCenterText(username);

	while (true) {
		//std::cout << "\n1. Scan Ports\n2. View Port Scan History\n3. Active Connections Monitor\n4. Crack Password with Hashfile\n5. Crack Password by brute force,(!n$t@gR@m)\n6. Logout\nChoice: ";
		coutCenterText(coutBoldText(coutBlueText("-----------------------------------------Network tools-------------------------------------------")));
		std::cout << "\n1. Scan Ports\n2. View Port Scan History\n3. Active Connections Monitor\n4. Crack Password with Hashfile\n5. Wireshark";
		coutCenterText(coutBoldText(coutBlueText("\n------------------------------------------Social Media-------------------------------------------")));
		std::cout << "\n6.Crack Password by brute force, (!n$t@gR@m)" << std::endl;
		coutCenterText(coutBoldText(coutBlueText("\n--------------------------------------------privacy----------------------------------------------")));
		std::cout << "\n7.Extract hidden metadata from images, PDFs, and videos" << std::endl;
		coutCenterText(coutBoldText(coutBlueText("\n---------------------------------------------Others----------------------------------------------")));
		std::cout << "\n7. Logout\n"<< std::endl;
		std::cout << "\nChoice: ";
		std::cin >> choice;

		if (choice == 1) {
			scanPorts(username);
		}
		else if (choice == 2) {
			viewHistory(username);
		}
		else if(choice == 3)
		{
			activeConnectionsMonitor();
		}
		else if (choice == 4) {
			askJohn();
		}
		else if (choice == 5) {
			 wiresharkmenu();
		}
		else if (choice == 6) {
			clearScreen();
			instaBruteForce();
		}
		else if (choice == 7) {
			exifTool();
		}
		else {
			std::cout << "Logging out...\n";
			break;
		}
	}
	return 0;
}