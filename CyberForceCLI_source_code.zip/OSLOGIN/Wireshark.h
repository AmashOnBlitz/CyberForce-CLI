#ifndef WIRESHARK_H
#define WIRESHARK_H

#include <iostream>
#include <string>  

class Wireshark {
public:
    void listInterfaces();
    void capturePackets(int interfaceNum);
    void saveCapture(int interfaceNum, const std::string& filename);
    void readCapture(const std::string& filename);
    void filterCapture(int interfaceNum, const std::string& filter);
    void extractIPs(int interfaceNum);
    void searchPackets(int interfaceNum, const std::string& keyword);
};

#endif // WIRESHARK_H
void wiresharkmenu();