#include <string>

void viewHistory(const std::string& username);
void scanPorts(const std::string& username);
void activeConnectionsMonitor();
void askJohn();
void runJohnTheRipper(const std::string& hashFile, int mode, const std::string& wordlist = "");
void instaBruteForce();
void exifTool();
void startWireshark();
